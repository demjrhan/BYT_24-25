﻿namespace Project.Interfaces
{
    public interface IYoung
    {
        public bool IsStudying { get; set; }
    }

}

