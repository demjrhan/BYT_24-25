﻿namespace Project
{
    public interface IAdult
    {
        public bool IsWorking { get; set; }
    }

}

