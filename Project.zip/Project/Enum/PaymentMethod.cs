﻿namespace Project.Enum
{
    public enum PaymentMethod
    {
        Cash,
        Card
    }
}
