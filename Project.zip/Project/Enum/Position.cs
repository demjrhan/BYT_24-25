﻿namespace Project.Enum
{
    public enum Position
    {
        Manager,
        Assistant
    }
}
