﻿namespace Project.Enum
{
    public enum MaterialType
    {
        Metal,
        Wood,
        Plastic,
        Gold,
        Leather
    }
}
