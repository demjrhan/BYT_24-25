﻿namespace Project.Enum
{
    public enum ReportType
    {
        Daily,
        Weekly,
        Monthly
    }
}
