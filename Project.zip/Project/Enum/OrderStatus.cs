﻿namespace Project.Enum
{
    public enum OrderStatus
    {
        //To change
        Proccessing,
        Departed,
        Arrived
    }
}
