﻿namespace Project.Enum
{
    public enum ShippingMethod
    {
        //Change later
        Default,
        Express
    }
}
