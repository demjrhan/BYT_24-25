﻿namespace Project.Enum
{
    public enum RetirementType
    {
        Military,
        HealthIssues,
        Other
    }
}
